package com.classpath.ordersapi.service;

import com.classpath.ordersapi.model.Role;
import com.classpath.ordersapi.model.User;
import com.classpath.ordersapi.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import java.util.Collection;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Primary
public class DomainUserDetailService implements UserDetailsService {
    private final UserRepository userRepository;
    @Override
    public UserDetails loadUserByUsername(String emailAddress) throws UsernameNotFoundException {
/*
        Optional<User> optionalUser = this.userRepository.findByEmail(emailAddress);
        if(optionalUser.isPresent()){
            return new DomainUserDetails(optionalUser.get());
        }else throw new UsernameNotFoundException("Invalid username/password");
*/
        Optional<User> domainUserDetails = this.userRepository.findByEmail(emailAddress);

        System.out.println(" User from the DB::::");

        domainUserDetails.get()
                .getRoles()
                .stream()
                .map(role -> role.getRoleName())
                .forEach(roleName -> System.out.println("Role name :: "+ roleName));

        return this.userRepository.findByEmail(emailAddress)
                                        .map(DomainUserDetails::new)
                                        .orElseThrow(() -> new UsernameNotFoundException("invalid username/password"));
    }
}

class DomainUserDetails implements UserDetails {

    private final User user;

    public DomainUserDetails(User user) {
        this.user = user;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return this.user.getRoles().stream()
                .map(Role::getRoleName)
                .map(roleName -> "ROLE_"+roleName)
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toSet());
    }

    @Override
    public String getPassword() {
        return this.user.getPassword();
    }

    @Override
    public String getUsername() {
        return this.user.getEmail();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}
