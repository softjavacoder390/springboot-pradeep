package com.classpath.ordersapi.config;

import com.classpath.ordersapi.service.DomainUserDetailService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@RequiredArgsConstructor
@Slf4j
public class ApplicationSecurityConfiguration extends WebSecurityConfigurerAdapter {

    private final DomainUserDetailService userDetailsService;
    private final PasswordEncoder passwordEncoder;

    //configuring authentication
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        log.info("configuring userdetails service");
        auth
                .userDetailsService(userDetailsService)
                .passwordEncoder(passwordEncoder);
    }


    //provide authorization

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.cors().disable();
        http.csrf().disable();
        http.headers().frameOptions().disable();
        http.authorizeRequests()
                .antMatchers("/h2-console/**", "/login/**", "/logout**", "/login**")
                .permitAll()
                .antMatchers(HttpMethod.GET, "/api/orders/**")
                .hasAnyRole("USER", "ADMIN")
                .antMatchers(HttpMethod.POST, "/api/orders/**")
                .hasRole("ADMIN")
                .and()
                .formLogin()
                .and()
                .httpBasic();
    }
}
