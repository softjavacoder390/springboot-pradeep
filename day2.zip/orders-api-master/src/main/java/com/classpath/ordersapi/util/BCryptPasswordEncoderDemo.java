package com.classpath.ordersapi.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class BCryptPasswordEncoderDemo {

    public static void main(String[] args) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String rawString  = "welcome";
        String encodedString = passwordEncoder.encode(rawString);
        String encodedString2 = passwordEncoder.encode(rawString);
        String encodedString3 = passwordEncoder.encode(rawString);
        String encodedString4 = passwordEncoder.encode(rawString);
        System.out.println(encodedString);
        System.out.println(encodedString2);
        System.out.println(encodedString3);
        System.out.println(encodedString4);

        System.out.println("Is password matches :: " + passwordEncoder.matches(rawString, encodedString));
        System.out.println("Is password matches :: " + passwordEncoder.matches(rawString, encodedString2));
        System.out.println("Is password matches :: " + passwordEncoder.matches(rawString, encodedString3));
        System.out.println("Is password matches :: " + passwordEncoder.matches(rawString, encodedString4));

    }
}
