package com.classpath.ordersapi.dto;

import java.util.Collection;

public interface Order {
    long getId();
    String getName();
    String getEmail();
    double getAmount();
}
