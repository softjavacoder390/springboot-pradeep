package com.classpath.ordersapi.config;

import com.classpath.ordersapi.model.User;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class ApplicationConfiguration {

    @Bean
    @ConditionalOnProperty(prefix = "app", value = "load-user", havingValue = "true", matchIfMissing = true)
    public User userBeanBasedOnPropertyCondition(){
        return new User();
    }
    @Bean
    @ConditionalOnBean(name = "userBeanBasedOnPropertyCondition")
    public User userBeanBasedOnBeanCondition(){
        return new User();
    }
    @Bean
    @ConditionalOnMissingBean(name = "userBeanBasedOnPropertyCondition")
    public User userBeanBasedOnMissingBeanCondition(){
        return new User();
    }

    @Bean
    public PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }
}


