package com.classpath.ordersapi.service;

import com.classpath.ordersapi.model.Order;
import com.classpath.ordersapi.repository.OrderRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@Slf4j
public class OrderService {
    private final OrderRepository orderRepository;
    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public Order saveOrder(Order order) {
        log.info("Saving the order :: {}", order);
        Order savedOrder = this.orderRepository.save(order);
        return savedOrder;
    }

    public Map<String, Object> fetchOrders(int page, int size, String strDirection, String property){
        Sort.Direction direction = strDirection.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageRequest = PageRequest.of(page, size, direction, property );
        Page<Order> pageResponse = this.orderRepository.findAll(pageRequest);

        long totalElements = pageResponse.getTotalElements();
        int totalPages = pageResponse.getTotalPages();
        int pageNumber = pageResponse.getNumber();
        List<Order> data = pageResponse.getContent();
        int numberOfElements = pageResponse.getNumberOfElements();

        LinkedHashMap<String, Object> responseMap = new LinkedHashMap<>();
        responseMap.put("total-records", totalElements);
        responseMap.put("pages", totalPages);
        responseMap.put("page-number", pageNumber);
        responseMap.put("number-of-elements", numberOfElements);
        responseMap.put("data", data);
        return responseMap;
    }

    public Order findById(long orderId){
/*
        Optional<Order> orderOptional = this.orderRepository.findById(orderId);
        if(orderOptional.isPresent()){
            return orderOptional.get();
        }
        throw new IllegalArgumentException("invalid order id");
*/
        return this.orderRepository
                        .findById(orderId)
                        .orElseThrow(() -> new IllegalArgumentException("invalid order id"));
    }

    public Map<String, Object> fetchOrdersByPriceRange(int page, int size, double min, double max){
        Pageable pageRequest = PageRequest.of(page, size, Sort.Direction.ASC, "name" );
        Page<com.classpath.ordersapi.dto.Order> pageResponse = this.orderRepository.findByAmountBetweenOrderByNameAsc(min, max, pageRequest);

        long totalElements = pageResponse.getTotalElements();
        int totalPages = pageResponse.getTotalPages();
        int pageNumber = pageResponse.getNumber();
        List<com.classpath.ordersapi.dto.Order> data = pageResponse.getContent();
        int numberOfElements = pageResponse.getNumberOfElements();

        LinkedHashMap<String, Object> responseMap = new LinkedHashMap<>();
        responseMap.put("total-records", totalElements);
        responseMap.put("pages", totalPages);
        responseMap.put("page-number", pageNumber);
        responseMap.put("number-of-elements", numberOfElements);
        responseMap.put("data", data);
        return responseMap;
    }

    public void deleteOrderById(long orderId){
        this.orderRepository.deleteById(orderId);
    }
}
