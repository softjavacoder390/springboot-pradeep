package com.classpath.ordersapi.model;

public class User {

}
